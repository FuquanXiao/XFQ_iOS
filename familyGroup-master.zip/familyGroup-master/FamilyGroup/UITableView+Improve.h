//
//  UITableView+Improve.h
//  MyFamily
//
//  Created by 陆洋 on 15/6/11.
//  Copyright (c) 2015年 maili. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITableView (Improve)
-(void)improveTableView;    //删除多余的行和防止分割线显示不全 
@end
