//
//  ReportStateViewController.h
//  MyFamily
//
//  Created by 陆洋 on 15/7/3.
//  Copyright (c) 2015年 maili. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ReportStateViewController : UITableViewController

@end
