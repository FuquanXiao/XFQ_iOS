//
//  UIImage+ReSize.h
//  MyFamily
//
//  Created by 陆洋 on 15/6/11.
//  Copyright (c) 2015年 maili. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (ReSize)
-(UIImage *)reSizeImagetoSize:(CGSize)reSize; //用来修改图片尺寸
@end
