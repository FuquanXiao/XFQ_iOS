//
//  HeaderContent.h
//  MyFamily
//
//  Created by 陆洋 on 15/6/2.
//  Copyright (c) 2015年 maili. All rights reserved.
//

#ifndef MyFamily_HeaderContent_h
#define MyFamily_HeaderContent_h
#define padding 10
#define screenWidth [UIScreen mainScreen].bounds.size.width
#define screenHeight [UIScreen mainScreen].bounds.size.height

//myfamily
#define myFamilyHeaderHeight 80
#define makeBookButtonHeight 60

#define imageTag 2000
#endif
