//
//  ShowImageViewController.h
//  MyFamily
//
//  Created by 陆洋 on 15/7/3.
//  Copyright (c) 2015年 maili. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShowImageViewController : UIViewController
@property (nonatomic,assign)NSInteger clickTag;
@property (nonatomic,strong)NSArray *imageViews;
@end
