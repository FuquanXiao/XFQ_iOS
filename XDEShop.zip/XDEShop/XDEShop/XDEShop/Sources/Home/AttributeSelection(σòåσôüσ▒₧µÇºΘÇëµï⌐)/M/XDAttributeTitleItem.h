//
//  XDAttributeTitleItem.h
//  XDEShop
//
//  Created by Celia on 2018/4/23.
//  Copyright © 2018年 Hopex. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XDAttributeTitleItem : NSObject

/** 标题名 */
@property (nonatomic, copy) NSString *attrname;


@end
