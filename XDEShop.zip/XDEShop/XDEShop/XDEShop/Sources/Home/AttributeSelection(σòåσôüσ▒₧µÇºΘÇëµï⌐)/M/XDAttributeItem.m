//
//  XDAttributeItem.m
//  XDEShop
//
//  Created by Celia on 2018/4/23.
//  Copyright © 2018年 Hopex. All rights reserved.
//

#import "XDAttributeItem.h"

@implementation XDAttributeItem

+ (NSDictionary *)mj_objectClassInArray
{
    return @{
             @"list" : @"XDAttributeList"
             };
}


@end
