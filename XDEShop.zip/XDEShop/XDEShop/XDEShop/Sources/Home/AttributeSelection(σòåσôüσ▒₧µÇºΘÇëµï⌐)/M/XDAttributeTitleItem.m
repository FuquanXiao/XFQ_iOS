//
//  XDAttributeTitleItem.m
//  XDEShop
//
//  Created by Celia on 2018/4/23.
//  Copyright © 2018年 Hopex. All rights reserved.
//

#import "XDAttributeTitleItem.h"

@implementation XDAttributeTitleItem

@end
