//
//  XDAttributeItemCell.h
//  XDEShop
//
//  Created by Celia on 2018/4/23.
//  Copyright © 2018年 Hopex. All rights reserved.
//

#import <UIKit/UIKit.h>

@class XDAttributeList;
@interface XDAttributeItemCell : UICollectionViewCell

/* 内容数据 */
@property (nonatomic, copy) XDAttributeList *content;

@end
