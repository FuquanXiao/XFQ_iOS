//
//  XDSearchStoreListViewController.h
//  B2B2C
//
//  Created by Celia on 2018/3/22.
//  Copyright © 2018年 HP. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XDSearchStoreListViewController : UIViewController

@end
