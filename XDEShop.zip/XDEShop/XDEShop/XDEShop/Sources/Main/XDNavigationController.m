//
//  XDNavigationController.m
//  XDEShop
//
//  Created by Celia on 2018/4/4.
//  Copyright © 2018年 Hopex. All rights reserved.
//

#import "XDNavigationController.h"

@interface XDNavigationController ()

@end

@implementation XDNavigationController

+ (void)initialize {
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
