//
//  XDPersonalViewController.h
//  XDEShop
//
//  Created by Celia on 2018/4/4.
//  Copyright © 2018年 Hopex. All rights reserved.
//

#import "XDBaseViewController.h"

@interface XDPersonalViewController : XDBaseViewController

@end
