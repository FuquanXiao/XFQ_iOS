//
//  NoNetShowView.h
//  HP_iOS_CommonFrame
//
//  Created by 秦正华 on 2017/8/11.
//  Copyright © 2017年 zhijianshangcheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HPReconnectView : UIView

@property (nonatomic, copy) void (^reconnectBlock)();

@end
