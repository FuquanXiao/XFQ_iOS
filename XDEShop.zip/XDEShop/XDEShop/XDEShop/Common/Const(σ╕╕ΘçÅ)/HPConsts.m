//
//  DCConsts.m
//  CDDMall
//
//  Created by apple on 2017/5/26.
//  Copyright © 2017年 RocketsChen. All rights reserved.
//


#import "HPConsts.h"

@implementation HPConsts

/** 常量数 */
CGFloat const kMargin = 10;

CGFloat const kScrollTitleViewH = 38;

CGFloat const kPageSize = 20;


NSString *const kGDMapApiKey = @"***";

NSString *const kHXAppKey = @"***";

NSString *const kHXApnsCertName = @"***";



@end
