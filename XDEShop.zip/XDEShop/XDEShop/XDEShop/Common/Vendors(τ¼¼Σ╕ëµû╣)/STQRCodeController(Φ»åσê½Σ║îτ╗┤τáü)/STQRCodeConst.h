//
//  STQRCodeConst.h
//  STQRCodeController
//
//  Created by ST on 16/11/28.
//  Copyright © 2016年 ST. All rights reserved.
//

#import <Foundation/Foundation.h>

#define ST_QRCODE_ScreenWidth  CGRectGetWidth([UIScreen mainScreen].bounds)
#define ST_QRCODE_ScreenHeight CGRectGetHeight([UIScreen mainScreen].bounds)
#define ST_QRCODE_WidthRate    ST_QRCODE_ScreenWidth/320

