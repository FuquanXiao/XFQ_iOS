//
//  YZFlowLayout.h
//  YZDisplayViewControllerDemo
//
//  Created by yz on 15/12/20.
//  Copyright © 2015年 yz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YZFlowLayout : UICollectionViewFlowLayout

@end
