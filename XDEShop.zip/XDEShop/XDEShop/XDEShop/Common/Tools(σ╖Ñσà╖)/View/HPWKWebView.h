//
//  XM_WKWebView.h
//  ZJSC
//
//  Created by 秦正华 on 2017/6/30.
//  Copyright © 2017年 zhijianshangcheng. All rights reserved.
//

#import <WebKit/WebKit.h>

/**
 *自定义WKWebView
 */
@interface HPWKWebView : WKWebView
/**webView的高度*/
@property(nonatomic,assign)CGFloat webViewHeight;

@end
