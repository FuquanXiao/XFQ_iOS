//
//  JLRefreshGifHeader.h
//  Jia-li Liu
//
//  Created by KLIANS on 2017/4/27.
//  Copyright © 2017年 KLIANS. All rights reserved.
//

#import <MJRefresh/MJRefresh.h>

@interface HPRefreshGifHeader : MJRefreshGifHeader

@end
